import { Song } from "../types";


const useLoadSongUrl = (song: Song) => {

  if (!song) {
    return '';
  }


  return ""
};

export default useLoadSongUrl;
