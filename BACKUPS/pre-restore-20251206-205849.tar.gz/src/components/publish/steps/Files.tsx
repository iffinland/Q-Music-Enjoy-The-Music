const Files = () => {
  return (
    <div className="rounded-md border border-dashed border-sky-700/60 bg-sky-900/30 p-4 text-sm text-sky-100/80">
      File uploads will live here. Drag & drop audio and cover assets in the next iteration.
    </div>
  )
}

export default Files
