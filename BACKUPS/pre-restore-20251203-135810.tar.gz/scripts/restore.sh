#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
REPO_ROOT="$(cd "$PROJECT_DIR/.." && pwd)"
BACKUP_DIR="$REPO_ROOT/BACKUPS"

usage() {
  cat <<'EOF'
Kasutus: scripts/restore.sh [faili_nimi_voi_taht]

Ilma argumendita küsitakse interaktiivselt, millist varukoopiat taastada.
Võib anda kas täisraja või BACKUPS kataloogis oleva faili nime.
EOF
}

choose_backup() {
  local input="${1:-}"
  local files

  IFS=$'\n' read -r -d '' -a files < <(ls -1t "$BACKUP_DIR"/*.tar.gz 2>/dev/null && printf '\0') || true

  if [[ ${#files[@]} -eq 0 ]]; then
    echo "Viga: BACKUPS kaustas pole ühtegi varukoopiat." >&2
    exit 1
  fi

  if [[ -n "$input" ]]; then
    if [[ -f "$input" ]]; then
      echo "$input"
      return
    fi
    if [[ -f "$BACKUP_DIR/$input" ]]; then
      echo "$BACKUP_DIR/$input"
      return
    fi
    echo "Viga: ei leidnud varukopia faili: $input" >&2
    exit 1
  fi

  echo "Vali taastatav varukoopia (uuemad ees):" >&2
  local i=1
  for f in "${files[@]}"; do
    echo "  $i) $(basename "$f")" >&2
    ((i++))
  done

  local choice
  while true; do
    printf "Sisesta number [1]: " >&2
    read -r choice
    choice=${choice:-1}
    if [[ "$choice" =~ ^[0-9]+$ ]] && (( choice >= 1 && choice <= ${#files[@]} )); then
      echo "${files[$((choice-1))]}"
      return
    fi
    echo "Palun vali number vahemikus 1..${#files[@]}." >&2
  done
}

create_safety_backup() {
  mkdir -p "$BACKUP_DIR"
  local ts="pre-restore-$(date +%Y%m%d-%H%M%S)"
  local out="$BACKUP_DIR/$ts.tar.gz"
  tar --exclude='.git' \
      --exclude='node_modules' \
      --exclude='dist' \
      --exclude='BACKUPS' \
      -czf "$out" \
      -C "$PROJECT_DIR" .
  echo "Loodud enne-taastamist varukoopia: $out"
}

restore_from_backup() {
  local backup_path="$1"
  local tmpdir

  tmpdir="$(mktemp -d)"
  trap 'rm -rf "$tmpdir"' EXIT

  echo "Lahtipakkimine: $backup_path"
  tar -xzf "$backup_path" -C "$tmpdir"

  echo "Sünkroonin varukoopia projekti kausta (kustutab vahepeal lisatud failid)."
  rsync -a --delete "$tmpdir"/ "$PROJECT_DIR"/

  echo "Taastamine valmis. Soovitus: käivita npm install && npm run build."
}

main() {
  if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
    usage
    exit 0
  fi

  mkdir -p "$BACKUP_DIR"

  local backup_path
  backup_path="$(choose_backup "${1:-}")"

  create_safety_backup
  restore_from_backup "$backup_path"
}

main "$@"
